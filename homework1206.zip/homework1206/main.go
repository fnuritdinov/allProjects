package main

/*
type Book struct {
	ID        int
	Title     string
	Author    string
	Pages     int
	Available bool
	CreatedAt time.Time
}

type BookManager interface {
	AddBook(book Book) error
	TakeBook(id int) error
	ReturnBook(id int) error
	ShowBooks()
}

type Library struct {
	books []Book
}

func (l *Library) AddBook(book Book) error {
	if book.ID <= 0 {
		return errors.New("Invalid ID")
	}

	if len(book.Title) == 0 {
		return errors.New("title is empty")
	}

	if book.Pages <= 0 {
		return errors.New("page is zero")
	}
	l.books = append(l.books, book)
	return nil

}

func (l *Library) TakeBook(id int) error {
	for i := range l.books {
		if l.books[i].ID == id {

			if !l.books[i].Available {
				return errors.New("book taken")
			}
			l.books[i].Available = false
			return nil
		}
	}
	return errors.New("book not found")
}

func (l *Library) ReturnBook(id int) error {
	for i := range l.books {
		if l.books[i].ID == id {

			if l.books[i].Available {
				return errors.New("book already true")
			}

			l.books[i].Available = true
			return nil
		}
	}

	return errors.New("book not found")
}

func (l *Library) ShowBooks() {
	for _, value := range l.books {
		fmt.Println(value)
	}
}

func (l *Library) BiggestBook() (string, error) {
	bigBook := 0
	bk := ""
	for _, value := range l.books {
		if value.Pages > bigBook {
			bigBook = value.Pages
			bk = value.Title
		}
	}
	return bk, nil
}

func (l *Library) TopAuthor() string {
	mapa := make(map[string]int)
	for _, value := range l.books {
		mapa[value.Author]++
	}
	topAuth := ""
	count := 0
	for key, value := range mapa {
		if value > count {
			count = value
			topAuth = key
		}
	}
	return topAuth
}

func (l *Library) Statistics(free int, taken int) {
	for _, value := range l.books {
		if value.Available {
			free++
			fmt.Println("Свободных", free)
		} else {
			taken++
			fmt.Println("Не свободных", taken)
		}
	}
	return
}

func (l *Library) SaveToFile(fileName string) error {
	file, err := os.Create(fileName)
	if err != nil {
		fmt.Println("Ошибка при создании файла")
	}
	defer file.Close()

	wrtr := bufio.NewWriter(file)

	for _, value := range l.books {
		line := fmt.Sprintf("%d,%s,%s,%d,%t,%s\n", value.ID, value.Author, value.Pages, value.Available, value.CreatedAt)
		wrtr.WriteString(line)
	}
	return wrtr.Flush()
}

func main() {

}

*/

// 2
/*
type Order struct {
	User    string
	Product string
	Price   float64
	Status  string
}

func ReadFile(fileName string) ([]Order, error) {
	file, err := os.Open(fileName)
	if err != nil {
		fmt.Println("Ошибка при открытии файла")
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)

	orders := []Order{}
	for scanner.Scan() {
		line := scanner.Text()
		field := strings.Fields(line)

		if len(field) != 4 {
			continue
		}

		price, err := strconv.ParseFloat(field[2], 64)
		if err != nil {
			continue
		}

		order := Order{
			User:    field[0],
			Product: field[1],
			Price:   price,
			Status:  field[3],
		}
		orders = append(orders, order)

	}
	return orders, nil
}

func SaveData(order Order) ([]Order, error) {
	saveData := []Order{}
	if len(order.User) == 0 {
		return []Order{}, errors.New("user is empty")
	}

	if len(order.Product) == 0 {
		return []Order{}, errors.New("product is empty")
	}

	if order.Price <= 0 {
		return []Order{}, errors.New("invalid price")
	}

	if order.Status != "new" && order.Status != "success" && order.Status != "failed" {
		return []Order{}, errors.New("invalid status")
	}
	saveData = append(saveData, order)
	return saveData, nil

}

func SuccessOrders(orders []Order) (int, error) {
	countOfDOne := 0
	for _, value := range orders {
		if value.Status == "success" {
			countOfDOne++
		}
	}
	return countOfDOne, nil
}

func FailedOrders(orders []Order) (int, error) {
	countOfFailed := 0
	for _, value := range orders {
		if value.Status == "failed" {
			countOfFailed++
		}
	}
	return countOfFailed, nil
}

func TotalSuccessOrders(orders []Order) (float64, error) {
	var total float64
	for _, value := range orders {
		if value.Status == "success" {
			total += value.Price
		}
	}
	return total, nil
}

func CountOrderOfUser(orders []Order) (map[string]int, error) {
	mapa := make(map[string]int)
	for _, value := range orders {
		mapa[value.User]++
	}
	return mapa, nil
}

func CountProductOrder(orders []Order) (map[string]int, error) {
	mapa := make(map[string]int)

	for _, value := range orders {
		mapa[value.Product]++
	}
	return mapa, nil
}

func ActiveUser(orders []Order) string {
	mapa := make(map[string]int)

	for _, value := range orders {
		mapa[value.User]++
	}

	topUser := ""
	maxC := 0

	for user, count := range mapa {
		if count > maxC {
			maxC = count
			topUser = user
		}
	}
	return topUser
}

func PopularProduct(orders []Order) string {
	mapa := make(map[string]int)

	for _, value := range orders {
		mapa[value.Product]++
	}
	topProd := ""
	maxC := 0
	for product, count := range mapa {
		if count > maxC {
			maxC = count
			topProd = product
		}
	}
	return topProd
}

func RichUser(orders []Order) string {
	mapa := make(map[string]float64)

	for _, value := range orders {
		if value.Status == "success" {
			mapa[value.User] += value.Price
		}
	}

	topUser := ""
	var maxC float64

	for user, money := range mapa {
		if money > maxC {
			maxC = money
			topUser = user
		}
	}
	return topUser
}

func main(){}

*/

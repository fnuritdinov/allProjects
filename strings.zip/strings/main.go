package main

// home work
// 1
/*
func main() {
	var str string
	fmt.Scan(&str)
	strRune := []rune(str)
	firstChar := strRune[0]
	lastChar := strRune[len(strRune)-1]

	fmt.Println(string(firstChar), string(lastChar))
}
*/

// 2
/*
func main() {
	var str string
	fmt.Scan(&str)

	count := strings.Count(str, "go")
	fmt.Println(count)
}
*/

// 3
/*
func main() {
	var str string
	reader := bufio.NewReader(os.Stdin)

	str, _ = reader.ReadString('\n')

	strRune := []rune(str)
	var slice []rune
	for i := 0; i < len(strRune); i++ {
		if strRune[i] != ' ' {
			slice = append(slice, strRune[i])
		}
	}
	fmt.Println(string(slice))
}*/

// 4
/*
func main() {

	var st string
	fmt.Scan(&st)
	stRune := []rune(st)

	count := 1
	for i := 1; i < len(stRune); i++ {
		if stRune[i] == stRune[i-1] {
			count++

		} else {

			fmt.Printf("%c%d", stRune[i-1], count)
			count = 1

		}
	}
	fmt.Printf("%c%d", stRune[len(stRune)-1], count)
}
*/

// 5
/*

func main() {
	var str string
	fmt.Scan(&str)
	strByte := []byte(str)
	left := 0
	right := len(strByte) - 1
	for left < right {
		if strByte[left] != strByte[right] {
			fmt.Println("NO")
			return
		}
		left++
		right--
	}
	fmt.Println("YES")
}
*/

package main

// homework
/*
type Notification struct {
	User    string
	Message string
}

type Sender interface {
	Send(n Notification) error
}

type EmailSender struct{}

func (e *EmailSender) Send(n Notification) error {
	if len(n.Message) == 0 {
		return errors.New("message is empty")
	}
	fmt.Println(n.User)
	return nil
}

type SmsSender struct{}

func (s *SmsSender) Send(n Notification) error {
	if len(n.Message) > 50 {
		return errors.New("error on len sms")
	}
	fmt.Println(n.User)
	return nil
}

func SendAll(senders []Sender, n Notification) []error {
	var Errors []error
	for _, value := range senders {
		errs := value.Send(n)
		if errs != nil {
			Errors = append(Errors, errs)
		}
	}
	return Errors
}

func SaveData(fileName string, data []Notification) error {
	file, err := os.Create(fileName)
	if err != nil {
		fmt.Println("error on open file")
	}
	defer file.Close()

	wrtr := bufio.NewWriter(file)

	for _, value := range data {
		line := fmt.Sprintf("user %s message %s", value.User, value.Message)
		wrtr.WriteString(line)
	}
	wrtr.Flush()
	return nil
}

func main() {
	senders := []Sender{}
	email := &EmailSender{}
	sms := &SmsSender{}
	senders = append(senders, email)
	senders = append(senders, sms)

	n := Notification{
		User:    "Ali",
		Message: "Hello",
	}

	errs := SendAll(senders, n)

	for _, value := range errs {
		fmt.Println(value)
	}
}

type Product struct {
	Name     string
	Category string
	Price    float64
	Quantity int
}

func TotalPrice(products []Product) float64 {
	var total float64
	for _, price := range products {
		total += price.Price * float64(price.Quantity)
	}
	return total
}

func MostExpensive(products []Product) Product {
	var mostExpensivePrice float64
	var expensiveProdust Product

	for _, value := range products {
		if value.Price > mostExpensivePrice {
			mostExpensivePrice = value.Price
			expensiveProdust = value
		}
	}
	return expensiveProdust
}

func CategoryStats(products []Product) map[string]int {
	prods := make(map[string]int)

	for _, value := range products {
		prods[value.Category]++
	}

	file, err := os.Create("stats.txt")
	if err != nil {
		fmt.Println("Ошибка при создании файла")
	}

	defer file.Close()

	wrtr := bufio.NewWriter(file)

	for key, value := range prods {
		line := fmt.Sprintf("category: %s count: %d\n", key, value)
		wrtr.WriteString(line)
	}
	wrtr.Flush()

	return prods
}

func main() {
	products := []Product{
		{
			Name:     "iphone",
			Category: "phone",
			Price:    950.0,
			Quantity: 2,
		},
		{
			Name:     "Samsung",
			Category: "phone",
			Price:    350.0,
			Quantity: 4,
		},
		{
			Name:     "Scanner",
			Category: "techs",
			Price:    1150.0,
			Quantity: 2,
		},
	}

	product := MostExpensive(products)
	fmt.Println(product)

	price := TotalPrice(products)
	fmt.Println(price)

	statistics := CategoryStats(products)
	fmt.Println(statistics)

}

*/

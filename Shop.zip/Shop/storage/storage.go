package storage

import "Shop/models"

func SeedProducts() []models.Product {
	products := []models.Product{
		{
			ID:       1,
			Name:     "iPhone 15",
			Price:    999.99,
			Quantity: 5,
		},
		{
			ID:       2,
			Name:     "MacBook Pro",
			Price:    1999.50,
			Quantity: 3,
		},
		{
			ID:       3,
			Name:     "AirPods Pro",
			Price:    249.99,
			Quantity: 10,
		},
		{
			ID:       4,
			Name:     "Samsung Galaxy S24",
			Price:    899.99,
			Quantity: 7,
		},
		{
			ID:       5,
			Name:     "PlayStation 5",
			Price:    599.99,
			Quantity: 4,
		},
	}
	return products
}

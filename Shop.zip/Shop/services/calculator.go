package services

import "Shop/models"

func TotalPrice(products []models.Product) float64 {
	var sum float64
	for _, product := range products {
		sum += product.Price
	}
	return sum

}

func MostExpensive(products []models.Product) models.Product {
	var expensiveProduct models.Product
	maxPr := 0.0
	for _, product := range products {
		if product.Price > maxPr {
			maxPr = product.Price
			expensiveProduct = product
		}

	}
	return expensiveProduct

}

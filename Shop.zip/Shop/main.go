package main

import (
	"Shop/services"
	"Shop/storage"
	"fmt"
)

func main() {
	products := storage.SeedProducts()
	fmt.Printf("Seed Products: %v\n", products)
	most := services.MostExpensive(products)
	fmt.Printf("Most Expensive: %v\n", most)
	total := services.TotalPrice(products)
	fmt.Printf("Total Price: %.2f\n", total)
}

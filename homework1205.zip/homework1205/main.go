package main

//classwork
/*
type Task struct {
	ID         int
	Title      string
	Status     string //new inProgress done
	Priority   int
	AssignedTo string
	CreatedAt  time.Time
}

func AddTask(tasks []Task, task Task) ([]Task, error) {

	if task.ID <= 0 {
		return []Task{}, errors.New("Invalid ID")
	}

	if len(task.Title) == 0 {
		return []Task{}, errors.New("title is empty")
	}

	if task.Status != "new" && task.Status != "inProgress" && task.Status != "done" {
		return []Task{}, errors.New("Invalid status")
	}

	if task.Priority < 1 {
		return []Task{}, errors.New("zero priority")
	}

	if len(task.AssignedTo) == 0 {
		return []Task{}, errors.New("AssignedTo is empty")
	}
	tasks = append(tasks, task)

	return tasks, nil

}

func GetTasks(tasks []Task) {
	for _, value := range tasks {
		fmt.Println(value)
	}
}

func DoneTasks(tasks []Task) []Task {
	DoneTsk := []Task{}
	for _, value := range tasks {
		if value.Status == "done" {
			DoneTsk = append(DoneTsk, value)
		}
	}
	return DoneTsk
}

func MaxPriority(tasks []Task) []Task {

	mxPriority := 0
	for _, value := range tasks {
		if value.Priority > mxPriority {
			mxPriority = value.Priority

		}
	}
	result := []Task{}

	for _, value := range tasks {
		if value.Priority == mxPriority {
			result = append(result, value)
		}

	}

	return result
}

func PersonWithManyTasks(tasks []Task) map[string]int {
	mapa := make(map[string]int)
	for _, value := range tasks {
		mapa[value.AssignedTo]++
	}
	fmt.Println(mapa)
	return mapa

}

func CountTasksForStatus(tasks []Task) map[string]int {
	data := make(map[string]int)
	for _, value := range tasks {
		data[value.Status]++
	}
	fmt.Println(data)
	return data
}

func WriteFunc(tasks []Task) {
	file, err := os.OpenFile("myFile.txt", os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		fmt.Println("Ошибка при открытии файла")
	}

	defer file.Close()

	wrtr := bufio.NewWriter(file)

	for _, v := range tasks {
		wrtr.WriteString(fmt.Sprintf("ID: %d\n Title: %s\n Status: %s\n Priority: %d\n AssignedTo: %s\n CreatedAt: %s\n",
			v.ID, v.Title, v.Status, v.Priority, v.AssignedTo, v.CreatedAt.Format(time.DateTime)))

	}
	wrtr.Flush()
}

func main() {

	tasks := []Task{}

	task1 := Task{
		ID:         1,
		Title:      "GO",
		Status:     "new",
		Priority:   10,
		AssignedTo: "Farrukh",
		CreatedAt:  time.Now(),
	}

	task2 := Task{
		ID:         2,
		Title:      "php",
		Status:     "done",
		Priority:   3,
		AssignedTo: "Ali",
		CreatedAt:  time.Now(),
	}

	task3 := Task{
		ID:         3,
		Title:      "php",
		Status:     "done",
		Priority:   3,
		AssignedTo: "Ali",
		CreatedAt:  time.Now(),
	}

	tasks, err := AddTask(tasks, task1)
	if err != nil {
		fmt.Println("Ошибка при создании таска")
	}
	fmt.Println(tasks)
	fmt.Println("first task")

	tasks, _ = AddTask(tasks, task2)
	fmt.Println(tasks)
	fmt.Println("second task")

	tasks, _ = AddTask(tasks, task3)
	fmt.Println(tasks)
	fmt.Println("third task")

	GetTasks(tasks)

	//WriteFunc(tasks)

	//data := CountTasksForStatus(tasks)
	//fmt.Println(data)

	//tasks = MaxPriority(tasks)
	//fmt.Println(tasks)

	//tsk := PersonWithManyTasks(tasks)
	//fmt.Println(tsk)

}

*/
// 2
/*
func ReadFile(fileName string) {
	file, err := os.Open(fileName)
	if err != nil {
		fmt.Println("Ошибка при открытии файла")
		return
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	userVisits := make(map[string]int)
	pageVists := make(map[string]int)
	for scanner.Scan() {
		line := scanner.Text()
		field := strings.Fields(line)
		if len(field) != 2 {
			continue
		}

		user := field[0]
		userVisits[user]++

		page := field[1]
		pageVists[page]++
	}

	mostActiveUser := ""
	maxUserVisits := 0

	for user, count := range userVisits {
		if count > maxUserVisits {
			maxUserVisits = count
			mostActiveUser = user
		}
	}

	mostPopularPage := ""
	maxPageVisits := 0

	for page, count := range pageVists {
		if count > maxPageVisits {
			maxPageVisits = count
			mostPopularPage = page
		}
	}

	for user, count := range userVisits {
		fmt.Println(user, count)
	}

	for page, count := range pageVists {
		fmt.Println(page, count)
	}

	fmt.Printf("Most active user %s\n", mostActiveUser)
	fmt.Printf("Most popular page %s\n", mostPopularPage)

	reportFile, err := os.Create("report.txt")
	if err != nil {
		fmt.Println("Ошибка при создании файла")
		return
	}

	defer reportFile.Close()

	writer := bufio.NewWriter(reportFile)

	for user, count := range userVisits {
		writer.WriteString(fmt.Sprintf("%s %d\n", user, count))
	}

	for page, count := range pageVists {
		writer.WriteString(fmt.Sprintf("%s %d\n", page, count))
	}

	writer.WriteString(fmt.Sprintf("%s %d\n", mostActiveUser, maxUserVisits))

	writer.WriteString(fmt.Sprintf("%s %d\n", mostPopularPage, maxPageVisits))

	writer.Flush()

	fmt.Println("\nОтчет сохранен в report.txt")

}

func main() {
	ReadFile("copyFile.txt")
}

*/

// homework
//1
/*
type Delivery interface {
	Calculate(weight float64) (float64, error)
}

type CarDelivery struct{}

type AirDelivery struct{}

type ExpressDelivery struct{}

func (c *CarDelivery) Calculate(weight float64) (float64, error) {
	if weight <= 0 {
		return 0, errors.New("invalid weight")
	}
	price := weight * 10

	return price, nil
}

func (a *AirDelivery) Calculate(weight float64) (float64, error) {
	if weight <= 0 {
		return 0, errors.New("invalid weight")
	}
	price := weight * 25
	if price < 100 {
		price = 100
	}
	return price, nil
}

func (e *ExpressDelivery) Calculate(weight float64) (float64, error) {
	if weight <= 0 {
		return 0, errors.New("invalid weight")
	}
	if weight > 10 {
		return 0, errors.New("price > 10")
	}
	price := weight * 40

	return price, nil
}

func CalculateAll(deliveries []Delivery, weight float64) ([]float64, []error) {
	sliceFloat := []float64{}
	sliceError := []error{}
	for _, value := range deliveries {
		price, err := value.Calculate(weight)
		if err != nil {
			sliceError = append(sliceError, err)
			continue
		}
		sliceFloat = append(sliceFloat, price)
	}
	return sliceFloat, sliceError

}

func main() {
	deliveries := []Delivery{
		&CarDelivery{},
		&AirDelivery{},
		&ExpressDelivery{},
	}

	prices, errs := CalculateAll(deliveries, 10)

	if errs != nil {
		fmt.Println("Error from CalculateAll")
	}
	fmt.Println(prices)
	fmt.Println(errs)
}

*/

// 2
/*
type Reader interface {
	Read(path string) ([]string, error)
}

type TxtReader struct{}

type CSVReader struct{}

func (t *TxtReader) Read(path string)([]string, error){
	if !strings.HasSuffix(path, ".txt"){
		return []string{}, errors.New("invalid type of file")
	}
	file, err := os.Open(path)
	if err != nil{
		fmt.Println("Ошибка при чтении файла")
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)

	sliceStr := []string{}
	for scanner.Scan() {
		line := scanner.Text()
		sliceStr = append(sliceStr, line)
	}
	return sliceStr, nil
}

func (csv *CSVReader) Read(path string) ([]string, error){
	if !strings.HasSuffix(path, ".csv"){
		return []string{}, errors.New("invalid type of file")
	}
	file, err := os.Open(path)
	if err != nil{
		return []string{}, errors.New("error for open file")
	}

	scanner := bufio.NewScanner(file)

	newSlice := []string{}
	for scanner.Scan() {
		line := scanner.Text()
		sliceSplit := strings.Split(line, ",")
		newSlice = append(newSlice, sliceSplit...)

	}
	return newSlice, nil
}

func ReadAll(readers []Reader, path string) [][]string{
	newSlice := [][]string{}
	for _, read := range readers{
		sl, err := read.Read(path)
		if err != nil{
			fmt.Println("error for reading")
			continue
		}
		newSlice = append(newSlice, sl)
	}
	return newSlice
}

func main() {
	file1 := []Reader{
		&CSVReader{},
	}
	sliceCSV := ReadAll(file1, "copy.csv")
	fmt.Println(sliceCSV)


	file2 := []Reader{
		&TxtReader{},
	}
	sliceTXT := ReadAll(file2, "report.txt")
	fmt.Println(sliceTXT)
}

*/

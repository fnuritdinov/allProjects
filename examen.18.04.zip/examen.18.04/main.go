package main

import ()

/*
func main() {
	a := normalizeName(" ss")
	fmt.Println(a)
}

func normalizeName(name string) string {
	n := strings.TrimSpace(name)
	strRune := []rune(n)
	if len(strRune) == 0 {
		return "Unknown"

	}
	return string(strRune)
}

*/

/*
func main() {
	u := &User{
		Name: "Ali",
		Age:  28,
	}

	UpdateUser(u, "Vali", 66)
	m := IsAdult(*u)
	fmt.Println(m)
	fmt.Printf("Name: %s, Age: %d\n", u.Name, u.Age)

}

type User struct {
	Name string
	Age  int
}

func UpdateUser(u *User, name string, age int) {
	u.Name = name
	if u.Age > 0 {
		u.Age = age

	}

}

func IsAdult(u User) bool {
	if u.Age >= 18 {
		return true
	}
	return false
}

*/
/*
func main() {
	ac := &Account{
		Balance: 20,
	}

	ac1 := &Account{
		Balance: 20,
	}

	Deposit(ac, 39)
	fmt.Println(ac)

	Withdraw(ac1, 2)
	fmt.Println(ac1)

}

type Account struct {
	Balance int
}

func Withdraw(acc *Account, amount int) bool {
	if acc.Balance >= amount {
		acc.Balance -= amount
		return true
	}
	return false

}

func Deposit(acc *Account, amount int) {
	if amount >= 0 {
		acc.Balance += amount
	}
}




func main() {
	us := &[]User{
		{Name: "Ali", Age: 33},
		{Name: "Vali", Age: 22},
	}
	addUser(us, User{Name: "DD", Age: 22})
	printUsers(*us)

	updateUserByName(us, "Ali", "Sergey", 11)
	printUsers(*us)
}

type User struct {
	Name string
	Age  int
}

func addUser(users *[]User, u User) []User {
	*users = append(*users, u)
	return []User{}
}

func updateUserByName(users *[]User, name string, newName string, newAge int) {
	for _, user := range *users {
		if name == user.Name {
			user.Name = newName
			user.Age = newAge
		}
	}
}

func printUsers(users []User) {
	fmt.Println(users)
}

package main

// classwork
//1
/*
type User struct {
	Name string `json:"name"`
	Age  int    `json:"age"`
}

func main() {
	var user User

	fmt.Scan(&user.Name)
	fmt.Scan(&user.Age)

	file, err := os.Create("file.txt")
	if err != nil {
		fmt.Println("Ошибка при создании файла")
	}
	defer file.Close()

	jsonData := fmt.Sprintf("имя %s\n возраст %d\n", user.Name, user.Age)

	_, err = file.WriteString(jsonData)
	if err != nil {
		fmt.Println("Ошибка при записи")
		return
	}

}

*/

//2
/*
type User struct{
	Name string `json: "name"`
	Age int `json: "age"`
}
func main() {
	file, _ := os.ReadFile("stats.json")


	var user User

	err := json.Unmarshal(file, &user)
	if err!= nil{
		fmt.Println(err)
	}
	fmt.Printf("name %s age %d", user.Name, user.Age)
}
*/

// 3
/*
type Student struct{
	Name string
	Grade int
}

func main() {
	student1 := Student{
		Name: "Ali",
		Grade: 10,
	}
	student2 := Student{
		Name: "Vali",
		Grade: 9,
	}
	student3 := Student{
		Name: "Anton",
		Grade: 8,
	}

	var students []Student

	students = append(students, student1)
	students = append(students, student2)
	students = append(students, student3)

	file, _ := os.Create("students.json")

	defer file.Close()

	wrtr := bufio.NewWriter(file)

	for _, student := range students{
		jsonText := fmt.Sprintf("name %s garde %d\n", student.Name, student.Grade)
		 wrtr.WriteString(jsonText)
	}
	wrtr.Flush()

}
*/

// 4
/*
type Student struct{
	Name string
	Grade int
}

func main() {
	file, _ := os.Open("students.json")

	var students []Student

	decoder := json.NewDecoder(file)

	_ = decoder.Decode(&students)

	var avg int

	for _, student := range students{
		avg += student.Grade
	}

	fmt.Println(avg)

}
*/

// 5
/*
type Student struct{
	Name string
	Grade int
}

func main() {
	var name string
	fmt.Scan(&name)
	var students []Student
	file, _ := os.Open("student.json")
	defer file.Close()

	decoder := json.NewDecoder(file)
	_ = decoder.Decode(&students)
	found := false
	for _, student := range students{
		if student.Name == name{
			fmt.Printf("name %s\n grade %d\n", student.Name, student.Grade)
			found = true
			break
		}

	}
	if !found {
			fmt.Println("student not found")
	}
}
*/
// 6
/*
type Student struct{
	Name string
	Grade int
}

func main() {
	file, _ := os.Open("students.json")
	defer file.Close()

	decoder := json.NewDecoder(file)

	var students []Student

	_ = decoder.Decode(&students)

	student1 := Student{
		Name: "Bzrg",
		Grade: 1,
	}

	students = append(students, student1)

	file1, err := os.OpenFile("students.json", os.O_RDWR | os.O_TRUNC, 0644)
	defer file1.Close()

	encoder := json.NewEncoder(file1)

	err = encoder.Encode(&students)
	if err != nil{
		fmt.Println(err)
	}
}
*/

// 7
/*
type Student struct {
	Name string
	Age  int
}

func main() {
	var name string

	fmt.Scan(&name)

	file, err := os.Open("student.json")
	if err != nil {
		panic(err)
	}
	defer file.Close()

	decoder := json.NewDecoder(file)

	var students []Student

	err = decoder.Decode(&students)
	if err != nil {
		panic(err)
	}

	updatesStudent := []Student{}

	for _, student := range students {
		if student.Name != name {
			updatesStudent = append(updatesStudent, student)
		}
	}

	data, _ := json.Marshal(updatesStudent)

	err = os.WriteFile("student.json", data, 0644)
	if err != nil {
		panic(err)
	}
}

*/

// 8

type Student struct {
	Name string
	Age  int
}

func main() {

}
